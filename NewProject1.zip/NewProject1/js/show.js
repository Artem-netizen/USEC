// const slide = document.querySelectorAll('.block');
// const slideItem = document.querySelectorAll('.carousel-slide');


// slide.forEach(function(item) {
//     item.addEventListener("click", function() {
//         let currentSlide = item;
//         let slideId = currentSlide.getAttribute("data-index");
//         let currentTab = document.querySelector(slideId);

//         console.log(slideId);

//         slide.forEach(function(item) {
//             item.classList.remove("see");
//         });
//         slideItem.forEach(function(item) {
//             item.classList.remove("see");
//         });

//         currentSlide.classList.add("see");
//         currentTab.classList.add("see");
//     })
// })