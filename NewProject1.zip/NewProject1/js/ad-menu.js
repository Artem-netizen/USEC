function toggle() {
    var menu = document.getElementById("mobile_nav");
    menu.classList.toggle("slide");
}